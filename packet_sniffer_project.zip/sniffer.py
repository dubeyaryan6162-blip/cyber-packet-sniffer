import argparse
from scapy.all import sniff, IP, TCP, UDP, ICMP, Ether, Raw
from scapy.layers import http
import datetime
import os

class PacketSniffer:
    def __init__(self, interface=None, log_file=None):
        self.interface = interface
        self.log_file = log_file
        if self.log_file:
            # Ensure the logs directory exists
            log_dir = os.path.dirname(self.log_file)
            if log_dir:
                os.makedirs(log_dir, exist_ok=True)

    def process_packet(self, packet):
        """
        Callback function to process each captured packet.
        """
        timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        packet_info = f"[{timestamp}] "

        if packet.haslayer(Ether):
            packet_info += f"Ether {packet[Ether].src} -> {packet[Ether].dst} | "

        if packet.haslayer(IP):
            ip_layer = packet[IP]
            packet_info += f"IP {ip_layer.src} -> {ip_layer.dst} | Proto: {ip_layer.proto} | "

            if packet.haslayer(TCP):
                tcp_layer = packet[TCP]
                packet_info += f"TCP {tcp_layer.sport} -> {tcp_layer.dport} [Flags: {tcp_layer.flags}]"
                
                # Check for HTTP
                if packet.haslayer(http.HTTPRequest):
                    try:
                        host = packet[http.HTTPRequest].Host.decode() if packet[http.HTTPRequest].Host else "N/A"
                        path = packet[http.HTTPRequest].Path.decode() if packet[http.HTTPRequest].Path else "N/A"
                        packet_info += f" | HTTP Request: {host}{path}"
                    except:
                        packet_info += " | HTTP Request (unparseable)"
                elif packet.haslayer(http.HTTPResponse):
                    packet_info += f" | HTTP Response"

            elif packet.haslayer(UDP):
                udp_layer = packet[UDP]
                packet_info += f"UDP {udp_layer.sport} -> {udp_layer.dport}"
                
                # Check for DNS
                if packet.haslayer('DNS'):
                    packet_info += " | DNS Query/Response"

            elif packet.haslayer(ICMP):
                packet_info += f"ICMP Type: {packet[ICMP].type}"

        # Print to console
        print(packet_info)

        # Log to file if specified
        if self.log_file:
            with open(self.log_file, "a") as f:
                f.write(packet_info + "\n")

    def start(self, count=0, filter_exp=None):
        """
        Start the sniffing process.
        """
        print(f"[*] Starting packet sniffer on interface: {self.interface or 'any'}")
        if filter_exp:
            print(f"[*] Applying filter: {filter_exp}")
        
        try:
            sniff(iface=self.interface, prn=self.process_packet, count=count, filter=filter_exp, store=0)
        except PermissionError:
            print("[!] Error: Root privileges required to sniff packets.")
        except Exception as e:
            print(f"[!] Error: {e}")

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="A simple Python-based Packet Sniffer")
    parser.add_argument("-i", "--interface", help="Network interface to sniff on (e.g., eth0, wlan0)")
    parser.add_argument("-c", "--count", type=int, default=0, help="Number of packets to capture (0 for infinite)")
    parser.add_argument("-f", "--filter", help="BPF filter expression (e.g., 'tcp port 80')")
    parser.add_argument("-l", "--log", help="Path to log file")

    args = parser.parse_args()

    sniffer = PacketSniffer(interface=args.interface, log_file=args.log)
    sniffer.start(count=args.count, filter_exp=args.filter)
